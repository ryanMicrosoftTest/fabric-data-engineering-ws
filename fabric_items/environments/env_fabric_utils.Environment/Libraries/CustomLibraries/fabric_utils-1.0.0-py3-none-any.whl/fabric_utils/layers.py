from enum import Enum

class Layer(Enum):
    BRONZE = "bronze"
    SILVER = "silver"
    PLATINUM = "platinum"
    GOLD = "gold"