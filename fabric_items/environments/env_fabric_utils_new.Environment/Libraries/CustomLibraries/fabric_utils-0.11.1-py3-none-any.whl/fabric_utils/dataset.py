import requests


class Dataset:
    def __init__(self, url):
        self.url = url

